## Search – and Find

So many texts, so many words? In case you lose track, Ulysses offers a number of search options.

First, there’s the option to filter your sheets, available at the top of the sheet list. It can be restricted to certain text elements, such as headings or comments. The tag icon next to the input field lets you search for sheets with keywords. 

In the editor, Find and Find & Replace are at your disposal via the Search icon.

### Quick Open

The fastest way to get to work is Quick Open. Try this:

- Hit `⌘O` to open the Quick Open panel.
- Enter a search term to scan the current section of your library, e.g. enter “Quick”.
- Click to get back here.

You can search for both phrases used in the text, and group names.


[Link](#)

The quick [brown](Test) fox [jumps](test) over the lazy dog. 


